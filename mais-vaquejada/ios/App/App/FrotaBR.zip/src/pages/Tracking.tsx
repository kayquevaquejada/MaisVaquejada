import React from 'react';
import { 
  Truck, 
  MapPin, 
  Navigation, 
  Layers, 
  Maximize2, 
  Search,
  ChevronRight,
  Info,
  Activity,
  Battery,
  Zap
} from 'lucide-react';
import { vehicles, trips } from '../mockData';
import { cn } from '../lib/utils';

export default function Tracking() {
  return (
    <div className="h-[calc(100vh-180px)] flex gap-8">
      {/* Live List */}
      <div className="w-80 flex flex-col bg-zinc-900/20 border border-zinc-800 rounded-sm shadow-2xl overflow-hidden">
        <div className="p-6 border-b border-zinc-800 flex items-center justify-between bg-[#0D0D0D]">
          <h3 className="text-xs font-bold text-zinc-100 uppercase tracking-[0.2em]">Neural Feed</h3>
          <div className="flex items-center gap-1.5 text-[9px] font-bold text-emerald-500 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded uppercase tracking-tighter">
            <span className="w-1 h-1 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]"></span>
            Live_Sync
          </div>
        </div>
        
        <div className="p-4 border-b border-zinc-800/50 bg-[#0D0D0D]/50">
          <div className="relative group">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-zinc-600 group-focus-within:text-zinc-100 transition-colors" />
            <input 
              type="text" 
              placeholder="SCAN_ASSETS..." 
              className="w-full pl-9 pr-3 py-2 bg-zinc-950 border border-zinc-800 rounded text-[10px] font-mono tracking-widest text-zinc-100 focus:outline-none focus:border-zinc-100/30"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {vehicles.filter(v => v.status === 'active').map((vehicle) => (
            <button 
              key={vehicle.id}
              className="w-full text-left p-4 bg-zinc-900/40 border border-zinc-800 hover:border-zinc-600 transition-all group relative overflow-hidden"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-mono font-bold text-emerald-500 uppercase tracking-[0.15em]">
                  {vehicle.plate}
                </span>
                <span className="text-[9px] text-zinc-500 font-bold font-mono tracking-tighter italic">85 KM/H</span>
              </div>
              <p className="text-xs font-bold text-zinc-100 uppercase tracking-tight line-clamp-1">{vehicle.model}</p>
              <div className="flex items-center gap-2 mt-2 text-[10px] text-zinc-600 font-mono tracking-tighter">
                <MapPin className="w-3 h-3 text-zinc-800" />
                <span className="truncate">{vehicle.location.address.toUpperCase()}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Simulated Map View */}
      <div className="flex-1 bg-black border border-zinc-800 relative overflow-hidden shadow-2xl group rounded-sm">
        {/* Dark Map Overlay (Simulated) */}
        <div className="absolute inset-0 bg-[url('https://api.mapbox.com/styles/v1/mapbox/dark-v11/static/-46.63, -23.55, 10, 0 /1280x800?access_token=pk.xxx')] bg-cover opacity-20 mix-blend-luminosity"></div>
        
        {/* Grid Background */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px]"></div>

        {/* Scan lines effect */}
        <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.1)_50%),linear-gradient(90deg,rgba(255,0,0,.03),rgba(0,255,0,.01),rgba(0,0,255,.03))] bg-[size:100%_2px,3px_100%] opacity-20"></div>

        {/* Map Controls */}
        <div className="absolute top-8 right-8 flex flex-col gap-3">
          <button className="p-3 bg-zinc-900/80 backdrop-blur border border-zinc-800 text-zinc-500 hover:text-zinc-100 hover:border-zinc-600 transition-all rounded shadow-xl">
            <Layers className="w-4 h-4" />
          </button>
          <button className="p-3 bg-zinc-900/80 backdrop-blur border border-zinc-800 text-zinc-500 hover:text-zinc-100 hover:border-zinc-600 transition-all rounded shadow-xl">
            <Maximize2 className="w-4 h-4" />
          </button>
          <div className="h-4 border-l-2 border-zinc-800 mx-auto"></div>
          <button className="p-3 bg-zinc-100 text-black border border-white hover:bg-white transition-all rounded shadow-2xl shadow-white/10">
            <Navigation className="w-4 h-4" />
          </button>
        </div>

        {/* Floating Vehicle Info */}
        <div className="absolute bottom-8 left-8 right-8">
          <div className="bg-zinc-950/90 backdrop-blur-xl border border-zinc-800 p-8 flex items-center justify-between shadow-2xl relative overflow-hidden group/panel">
            {/* Background texture for panel */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_-20%,rgba(16,185,129,0.05),transparent)] pointer-events-none"></div>

            <div className="flex items-center gap-6 relative z-10">
              <div className="w-14 h-14 bg-zinc-100 rounded flex items-center justify-center text-black shadow-[0_0_20px_rgba(255,255,255,0.1)]">
                <Truck className="w-7 h-7" />
              </div>
              <div>
                <div className="flex items-center gap-3 mb-1">
                  <h4 className="text-lg font-light text-zinc-100 tracking-tighter">ABC-1234</h4>
                  <div className="flex items-center gap-1.5 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 text-[9px] font-bold text-emerald-500 uppercase tracking-widest rounded">
                    <Zap className="w-2 h-2 fill-emerald-500" /> Moving
                  </div>
                </div>
                <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Enroute: Curitiba, PR // BR-116</p>
              </div>
            </div>

            <div className="flex items-center gap-12 px-12 border-l border-zinc-800 relative z-10">
              <div className="text-center">
                <p className="text-[10px] font-bold text-zinc-600 uppercase tracking-[0.2em] mb-2">Velocity</p>
                <p className="text-2xl font-light text-zinc-100 tracking-tighter">82 <span className="text-xs text-zinc-600 uppercase font-mono italic">km/h</span></p>
              </div>
              <div className="text-center">
                <p className="text-[10px] font-bold text-zinc-600 uppercase tracking-[0.2em] mb-2">Tonnage</p>
                <p className="text-2xl font-light text-zinc-100 tracking-tighter">12.5 <span className="text-xs text-zinc-600 uppercase font-mono italic">t</span></p>
              </div>
              <div className="text-center">
                <p className="text-[10px] font-bold text-zinc-600 uppercase tracking-[0.2em] mb-2">Energy</p>
                <div className="flex items-center justify-center gap-2">
                  <Battery className="w-4 h-4 text-emerald-500" />
                  <p className="text-2xl font-light text-emerald-500 tracking-tighter">92%</p>
                </div>
              </div>
            </div>

            <button className="bg-zinc-100 hover:bg-white text-black px-8 py-3 text-[11px] font-bold uppercase tracking-widest transition-all shadow-xl shadow-white/5 relative z-10">
              System Telemetry
            </button>
          </div>
        </div>

        {/* Dummy Vehicle Markers */}
        <div className="absolute top-1/3 left-1/4">
          <div className="relative group/marker cursor-pointer">
            <div className="absolute inset-0 bg-emerald-500 rounded-full blur-2xl opacity-0 group-hover:opacity-40 transition-opacity scale-150"></div>
            <div className="w-5 h-5 bg-zinc-100 border-4 border-black rounded shadow-[0_0_15px_rgba(255,255,255,0.3)] animate-pulse"></div>
            <div className="absolute top-8 left-1/2 -translate-x-1/2 whitespace-nowrap bg-black border border-zinc-800 px-3 py-1.5 text-[9px] font-mono font-bold text-zinc-100 shadow-2xl tracking-widest uppercase">
              ASSET_ABC_1234
            </div>
          </div>
        </div>

        <div className="absolute top-2/3 right-1/3">
          <div className="relative group/marker cursor-pointer">
            <div className="w-5 h-5 bg-zinc-100 border-4 border-black rounded shadow-[0_0_15px_rgba(255,255,255,0.3)]"></div>
            <div className="absolute top-8 left-1/2 -translate-x-1/2 whitespace-nowrap bg-black border border-zinc-800 px-3 py-1.5 text-[9px] font-mono font-bold text-zinc-100 shadow-2xl tracking-widest uppercase">
              ASSET_XYZ_5678
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
