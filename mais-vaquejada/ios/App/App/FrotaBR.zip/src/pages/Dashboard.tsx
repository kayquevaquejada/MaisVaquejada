import React from 'react';
import { 
  Truck, 
  Users, 
  AlertTriangle, 
  TrendingUp,
  MapPin,
  Clock,
  ChevronRight,
  Activity,
  Cpu
} from 'lucide-react';
import { vehicles, drivers, trips } from '../mockData';
import { cn } from '../lib/utils';

const stats = [
  { name: 'Active Vehicles', value: '12', icon: Truck, color: 'text-zinc-100', bg: 'bg-zinc-800', change: 'SYS_NOMINAL' },
  { name: 'Drivers on Duty', value: '45', icon: Users, color: 'text-emerald-500', bg: 'bg-emerald-500/10', change: '8 IDLE' },
  { name: 'Priority Alerts', value: '3', icon: AlertTriangle, color: 'text-amber-500', bg: 'bg-amber-500/10', change: '1 CRITICAL' },
  { name: 'Efficiency', value: '94%', icon: TrendingUp, color: 'text-zinc-100', bg: 'bg-zinc-800', change: '+1.2% LOAD' },
];

export default function Dashboard() {
  return (
    <div className="space-y-12">
      <header className="flex justify-between items-end border-b border-zinc-800 pb-8">
        <div>
          <h2 className="text-xs font-bold text-zinc-500 uppercase tracking-[0.2em] mb-2">Operational Pulse</h2>
          <div className="flex items-center gap-4">
            <span className="text-4xl font-light text-zinc-100 tracking-tighter">Fleet <span className="italic font-serif text-zinc-500">Overview</span></span>
            <div className="px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 text-[10px] font-bold tracking-widest rounded uppercase">Live</div>
          </div>
        </div>
        <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Global Status: Synchronized</p>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-zinc-800 border border-zinc-800 overflow-hidden rounded-sm shadow-2xl">
        {stats.map((stat) => (
          <div key={stat.name} className="bg-[#0D0D0D] p-8 flex flex-col gap-4 group hover:bg-[#121212] transition-colors">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">{stat.name}</span>
              <stat.icon className={cn("w-4 h-4", stat.color)} />
            </div>
            <div>
              <h3 className="text-4xl font-light text-zinc-100 tracking-tighter mb-1">{stat.value}</h3>
              <p className={cn("text-[10px] font-mono tracking-widest", stat.color.includes('emerald') || stat.color.includes('zinc') ? 'text-zinc-600' : stat.color)}>{stat.change}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Active Deliveries */}
        <div className="lg:col-span-8 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-[0.2em]">Service Stack // Active</h3>
            <button className="text-[10px] text-zinc-100 font-bold uppercase tracking-widest hover:underline flex items-center">
              Telemetry Log <ChevronRight className="w-3 h-3 ml-2" />
            </button>
          </div>
          
          <div className="space-y-4">
            {trips.map((trip) => {
              const vehicle = vehicles.find(v => v.id === trip.vehicleId);
              const driver = drivers.find(d => d.id === trip.driverId);
              
              return (
                <div key={trip.id} className="bg-zinc-900/30 border border-zinc-800 p-6 flex flex-col md:flex-row items-start md:items-center gap-6 group hover:border-zinc-700 transition-all">
                  <div className="w-12 h-12 bg-zinc-800 rounded flex items-center justify-center border border-zinc-700 group-hover:bg-zinc-100 group-hover:text-black transition-all">
                    <Activity className="w-5 h-5" />
                  </div>
                  
                  <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div>
                      <p className="text-[10px] font-mono text-zinc-600 uppercase tracking-widest mb-1 font-bold">Relay Point</p>
                      <p className="text-sm font-medium text-zinc-100 uppercase tracking-tight">{trip.origin} <span className="text-zinc-600 mx-1">→</span> {trip.destination}</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-mono text-zinc-600 uppercase tracking-widest mb-1 font-bold">Operator</p>
                      <p className="text-sm font-medium text-zinc-100">{driver?.name.toUpperCase()}</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-mono text-zinc-600 uppercase tracking-widest mb-1 font-bold">Asset ID</p>
                      <p className="text-sm font-mono text-zinc-100 bg-zinc-800 border border-zinc-700 px-2 py-0.5 rounded-sm inline-block">{vehicle?.plate}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-6 border-l border-zinc-800 pl-6 h-12">
                    <div className="text-right">
                      <p className="text-[10px] font-mono text-zinc-600 uppercase tracking-widest font-bold">T-Minus</p>
                      <p className="text-lg font-light text-zinc-100 tracking-tighter">02:45 <span className="text-xs text-zinc-500 uppercase font-mono">hrs</span></p>
                    </div>
                    <div className="w-2 h-2 bg-emerald-500 rounded-full shadow-[0_0_8px_rgba(16,185,129,0.4)] animate-pulse"></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* System Logs */}
        <div className="lg:col-span-4 space-y-6">
          <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-[0.2em]">Console Output</h3>
          <div className="bg-black border border-zinc-800 p-6 space-y-6 rounded-sm shadow-xl font-mono text-[11px] leading-relaxed relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
              <Cpu className="w-24 h-24" />
            </div>

            <div className="space-y-4">
              <div className="group">
                <div className="text-emerald-500/80 mb-1 flex items-center justify-between uppercase tracking-tighter font-bold">
                  <span>[22:38:01] NOMINAL_REPORT</span>
                  <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div>
                </div>
                <p className="text-zinc-500 leading-tight">Vehicle ABC-1234 reached checkpoint GAMMA. Speed maintained at 85KM/H.</p>
              </div>

              <div className="group">
                <div className="text-amber-500/80 mb-1 flex items-center justify-between uppercase tracking-tighter font-bold">
                  <span>[22:39:14] SCHED_ALERT</span>
                  <div className="w-1.5 h-1.5 bg-amber-500 rounded-full"></div>
                </div>
                <p className="text-zinc-500 leading-tight">Maintenance cycle for DEF-9012 is overdue. Risk level: ELEVATED.</p>
              </div>

              <div className="group">
                <div className="text-zinc-500 mb-1 flex items-center justify-between uppercase tracking-tighter font-bold">
                  <span>[22:40:45] NET_HANDSHAKE</span>
                </div>
                <p className="text-zinc-600 leading-tight">Operator Ana Costa initialized route RJ-02. Handlers mounted successfully.</p>
              </div>
            </div>

            <div className="pt-4 border-t border-zinc-800 flex flex-col gap-2">
              <div className="flex items-center gap-2 text-zinc-700">
                <span className="w-1 h-1 bg-zinc-700 rounded-full"></span>
                <span>FETCHING_DATA_STREAM...</span>
              </div>
              <div className="flex items-center gap-2 text-zinc-400 italic">
                <ChevronRight className="w-3 h-3" />
                <span>SYSTEM STANDING BY.</span>
              </div>
              <div className="w-1.5 h-3 bg-zinc-100 animate-pulse mt-2"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
