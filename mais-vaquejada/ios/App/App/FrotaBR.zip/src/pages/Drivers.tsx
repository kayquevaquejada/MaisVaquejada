import React from 'react';
import { 
  Users, 
  Search, 
  Filter, 
  Plus, 
  Star, 
  Phone, 
  Mail,
  MoreHorizontal
} from 'lucide-react';
import { drivers } from '../mockData';
import { cn } from '../lib/utils';

export default function Drivers() {
  return (
    <div className="space-y-12">
      <div className="flex items-center justify-between border-b border-zinc-800 pb-8">
        <div>
          <h2 className="text-xs font-bold text-zinc-500 uppercase tracking-[0.2em] mb-2">Personnel Directory</h2>
          <h1 className="text-4xl font-light text-zinc-100 tracking-tighter">Operator <span className="italic font-serif text-zinc-500">Registry</span></h1>
        </div>
        <button className="bg-zinc-100 text-black px-6 py-3 font-bold text-[11px] uppercase tracking-widest flex items-center gap-2 hover:bg-white transition-all shadow-[0_0_20px_rgba(255,255,255,0.05)]">
          <Plus className="w-4 h-4" />
          Assign Operator
        </button>
      </div>

      <div className="flex gap-4 flex-col sm:flex-row">
        <div className="relative flex-1 group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600 group-focus-within:text-zinc-100 transition-colors" />
          <input 
            type="text" 
            placeholder="SCAN BY NAME, CONTACT, OR CLEARANCE..." 
            className="w-full pl-12 pr-4 py-3 bg-zinc-900/50 border border-zinc-800 rounded text-[11px] font-mono tracking-widest text-zinc-100 focus:outline-none focus:border-zinc-100/50 transition-all placeholder:text-zinc-700"
          />
        </div>
        <button className="px-6 py-3 bg-zinc-900/50 border border-zinc-800 text-[11px] font-bold uppercase tracking-widest text-zinc-400 flex items-center gap-2 hover:text-zinc-100 hover:bg-zinc-800 transition-all">
          <Filter className="w-4 h-4" />
          Parameters
        </button>
      </div>

      <div className="bg-zinc-900/20 border border-zinc-800 rounded-sm overflow-hidden shadow-2xl">
        <table className="w-full text-left">
          <thead className="bg-[#0D0D0D] border-b border-zinc-800">
            <tr>
              <th className="px-8 py-5 text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em]">Personnel</th>
              <th className="px-8 py-5 text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em]">State</th>
              <th className="px-8 py-5 text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em]">Clearance</th>
              <th className="px-8 py-5 text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em]">Rating</th>
              <th className="px-8 py-5 text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em]">Comms</th>
              <th className="px-8 py-5 text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em]"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-800/50">
            {drivers.map((driver) => (
              <tr key={driver.id} className="hover:bg-zinc-900/40 transition-colors group">
                <td className="px-8 py-5">
                  <div className="flex items-center gap-4">
                    <img src={driver.avatar} alt={driver.name} className="w-10 h-10 rounded border border-zinc-800 grayscale group-hover:grayscale-0 transition-all" />
                    <div>
                      <p className="text-xs font-bold text-zinc-100 uppercase tracking-tight">{driver.name}</p>
                      <p className="text-[10px] font-mono text-zinc-600">ID: {driver.id}</p>
                    </div>
                  </div>
                </td>
                <td className="px-8 py-5">
                  <div className={cn(
                    "inline-flex items-center gap-2 px-3 py-1 border text-[10px] font-bold uppercase tracking-[0.1em]",
                    driver.status === 'on-trip' ? "bg-zinc-800 border-zinc-700 text-zinc-400" :
                    driver.status === 'available' ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-500" :
                    "bg-zinc-800 border-zinc-800 text-zinc-600"
                  )}>
                    <div className={cn(
                      "w-1 h-1 rounded-full",
                      driver.status === 'on-trip' ? "bg-zinc-400" :
                      driver.status === 'available' ? "bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.4)]" :
                      "bg-zinc-600"
                    )}></div>
                    {driver.status.replace('-', ' ')}
                  </div>
                </td>
                <td className="px-8 py-5">
                  <span className="text-[11px] font-mono text-zinc-500 uppercase tracking-widest">{driver.license}</span>
                </td>
                <td className="px-8 py-5">
                  <div className="flex items-center gap-1.5">
                    <Star className="w-3.5 h-3.5 text-zinc-700 fill-zinc-700 group-hover:text-emerald-500 group-hover:fill-emerald-500 transition-colors" />
                    <span className="text-[11px] font-bold text-zinc-200">{driver.rating}</span>
                  </div>
                </td>
                <td className="px-8 py-5">
                  <div className="flex items-center gap-3">
                    <button className="p-2.5 bg-zinc-900 border border-zinc-800 text-zinc-600 hover:text-zinc-100 hover:border-zinc-700 transition-all" title="Call">
                      <Phone className="w-3.5 h-3.5" />
                    </button>
                    <button className="p-2.5 bg-zinc-900 border border-zinc-800 text-zinc-600 hover:text-zinc-100 hover:border-zinc-700 transition-all" title="Email">
                      <Mail className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </td>
                <td className="px-8 py-5 text-right">
                  <button className="p-2 text-zinc-700 hover:text-zinc-200 transition-colors">
                    <MoreHorizontal className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
