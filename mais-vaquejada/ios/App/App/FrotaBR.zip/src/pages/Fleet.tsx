import React from 'react';
import { 
  Truck, 
  MapPin, 
  Search, 
  Filter, 
  MoreVertical, 
  Calendar, 
  Activity,
  Plus,
  Box
} from 'lucide-react';
import { vehicles } from '../mockData';
import { cn } from '../lib/utils';

export default function Fleet() {
  return (
    <div className="space-y-12">
      <div className="flex items-center justify-between border-b border-zinc-800 pb-8">
        <div>
          <h2 className="text-xs font-bold text-zinc-500 uppercase tracking-[0.2em] mb-2">Asset Inventory</h2>
          <h1 className="text-4xl font-light text-zinc-100 tracking-tighter">Vehicle <span className="italic font-serif text-zinc-500">Fleet</span></h1>
        </div>
        <button className="bg-zinc-100 text-black px-6 py-3 font-bold text-[11px] uppercase tracking-widest flex items-center gap-2 hover:bg-white transition-all shadow-[0_0_20px_rgba(255,255,255,0.05)]">
          <Plus className="w-4 h-4" />
          Deploy Unit
        </button>
      </div>

      <div className="flex gap-4 flex-col sm:flex-row">
        <div className="relative flex-1 group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600 group-focus-within:text-zinc-100 transition-colors" />
          <input 
            type="text" 
            placeholder="SCAN BY MODEL, REGISTRY, OR OPERATOR..." 
            className="w-full pl-12 pr-4 py-3 bg-zinc-900/50 border border-zinc-800 rounded text-[11px] font-mono tracking-widest text-zinc-100 focus:outline-none focus:border-zinc-100/50 transition-all placeholder:text-zinc-700"
          />
        </div>
        <button className="px-6 py-3 bg-zinc-900/50 border border-zinc-800 text-[11px] font-bold uppercase tracking-widest text-zinc-400 flex items-center gap-2 hover:text-zinc-100 hover:bg-zinc-800 transition-all">
          <Filter className="w-4 h-4" />
          Parameters
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {vehicles.map((vehicle) => (
          <div key={vehicle.id} className="bg-zinc-900/20 border border-zinc-800 flex flex-col group hover:border-zinc-100/30 transition-all relative overflow-hidden">
            <div className="p-8">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-zinc-800 rounded flex items-center justify-center text-zinc-400 group-hover:bg-zinc-100 group-hover:text-black transition-all border border-zinc-700">
                    <Box className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-zinc-100 uppercase tracking-tight">{vehicle.model}</h3>
                    <p className="text-[10px] font-mono font-bold text-emerald-500 uppercase tracking-widest mt-0.5">{vehicle.plate}</p>
                  </div>
                </div>
                <button className="p-2 text-zinc-600 hover:text-zinc-100 transition-colors">
                  <MoreVertical className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-3">
                  <MapPin className="w-4 h-4 text-zinc-700" />
                  <span className="text-[11px] font-medium text-zinc-400 uppercase tracking-tight">{vehicle.location.address}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Activity className="w-4 h-4 text-zinc-700" />
                  <span className="text-[11px] font-mono text-zinc-500">{vehicle.mileage.toLocaleString()} KM // TOTAL_OVAL</span>
                </div>
                <div className="flex items-center gap-3">
                  <Calendar className="w-4 h-4 text-zinc-700" />
                  <span className="text-[11px] font-mono text-zinc-500">LAST_SVC: {vehicle.lastMaintenance}</span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-6 border-t border-zinc-800">
                <div className={cn(
                  "px-3 py-1 text-[10px] font-bold tracking-widest border uppercase",
                  vehicle.status === 'active' ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-500" :
                  vehicle.status === 'maintenance' ? "bg-amber-500/10 border-amber-500/30 text-amber-500" :
                  "bg-zinc-800 border-zinc-700 text-zinc-500"
                )}>
                  {vehicle.status}
                </div>
                <button className="text-[10px] font-bold text-zinc-100 hover:underline uppercase tracking-widest">
                  Live Feed
                </button>
              </div>
            </div>
            
            {/* Corner Accent */}
            <div className="absolute top-0 right-0 w-8 h-8 pointer-events-none overflow-hidden">
               <div className="absolute top-[-20px] right-[-20px] w-10 h-10 border border-zinc-800 rotate-45"></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
