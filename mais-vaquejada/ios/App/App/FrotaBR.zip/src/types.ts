export type VehicleStatus = 'active' | 'maintenance' | 'idle' | 'retired';

export interface Vehicle {
  id: string;
  plate: string;
  model: string;
  type: 'truck' | 'van' | 'car';
  status: VehicleStatus;
  currentDriverId?: string;
  lastMaintenance: string;
  mileage: number;
  location: {
    lat: number;
    lng: number;
    address: string;
  };
}

export interface Driver {
  id: string;
  name: string;
  license: string;
  status: 'available' | 'on-trip' | 'off-duty';
  rating: number;
  email: string;
  phone: string;
  avatar: string;
}

export interface Trip {
  id: string;
  vehicleId: string;
  driverId: string;
  origin: string;
  destination: string;
  startTime: string;
  endTime?: string;
  status: 'pending' | 'in-progress' | 'completed' | 'cancelled';
  distance: number;
}

export interface DashboardStats {
  activeVehicles: number;
  onTripDrivers: number;
  maintenanceRequired: number;
  monthlyRevenue: number;
}
