import { Vehicle, Driver, Trip } from './types';

export const vehicles: Vehicle[] = [
  {
    id: '1',
    plate: 'ABC-1234',
    model: 'Mercedes-Benz Actros',
    type: 'truck',
    status: 'active',
    currentDriverId: '101',
    lastMaintenance: '2025-01-15',
    mileage: 45000,
    location: {
      lat: -23.55052,
      lng: -46.633308,
      address: 'São Paulo, SP'
    }
  },
  {
    id: '2',
    plate: 'XYZ-5678',
    model: 'Scania R450',
    type: 'truck',
    status: 'active',
    currentDriverId: '102',
    lastMaintenance: '2025-02-10',
    mileage: 32000,
    location: {
      lat: -22.906847,
      lng: -43.172896,
      address: 'Rio de Janeiro, RJ'
    }
  },
  {
    id: '3',
    plate: 'DEF-9012',
    model: 'Mercedes-Benz Sprinter',
    type: 'van',
    status: 'maintenance',
    lastMaintenance: '2025-03-01',
    mileage: 85000,
    location: {
      lat: -19.916681,
      lng: -43.934493,
      address: 'Belo Horizonte, MG'
    }
  },
  {
    id: '4',
    plate: 'GHI-3456',
    model: 'Volvo FH16',
    type: 'truck',
    status: 'active',
    currentDriverId: '103',
    lastMaintenance: '2025-01-20',
    mileage: 12000,
    location: {
      lat: -15.797515,
      lng: -47.891887,
      address: 'Brasília, DF'
    }
  }
];

export const drivers: Driver[] = [
  {
    id: '101',
    name: 'Roberto Silva',
    license: 'Cat. E',
    status: 'on-trip',
    rating: 4.8,
    email: 'roberto@frotago.com',
    phone: '+55 11 98888-8888',
    avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=100&h=100&fit=crop'
  },
  {
    id: '102',
    name: 'Ana Costa',
    license: 'Cat. D',
    status: 'on-trip',
    rating: 4.9,
    email: 'ana@frotago.com',
    phone: '+55 21 97777-7777',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop'
  },
  {
    id: '103',
    name: 'Carlos Oliveira',
    license: 'Cat. E',
    status: 'on-trip',
    rating: 4.7,
    email: 'carlos@frotago.com',
    phone: '+55 61 96666-6666',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop'
  },
  {
    id: '104',
    name: 'Juliana Mendes',
    license: 'Cat. B',
    status: 'available',
    rating: 5.0,
    email: 'juliana@frotago.com',
    phone: '+55 11 95555-5555',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop'
  }
];

export const trips: Trip[] = [
  {
    id: 't1',
    vehicleId: '1',
    driverId: '101',
    origin: 'São Paulo, SP',
    destination: 'Curitiba, PR',
    startTime: '2025-04-20T08:00:00Z',
    status: 'in-progress',
    distance: 408
  },
  {
    id: 't2',
    vehicleId: '2',
    driverId: '102',
    origin: 'Rio de Janeiro, RJ',
    destination: 'Vitória, ES',
    startTime: '2025-04-21T10:00:00Z',
    status: 'in-progress',
    distance: 520
  }
];
