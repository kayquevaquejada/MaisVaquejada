import React from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Truck, 
  Users, 
  Map as MapIcon, 
  Settings, 
  Bell, 
  Search,
  LogOut,
  Cpu
} from 'lucide-react';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

const navItems = [
  { name: 'Dashboard', path: '/', icon: LayoutDashboard },
  { name: 'Fleet', path: '/fleet', icon: Truck },
  { name: 'Drivers', path: '/drivers', icon: Users },
  { name: 'Tracking', path: '/tracking', icon: MapIcon },
  { name: 'Settings', path: '/settings', icon: Settings },
];

export default function Layout() {
  return (
    <div className="flex h-screen bg-[#0A0A0A] text-zinc-300 font-sans overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-[#0D0D0D] border-r border-zinc-800 flex flex-col flex-shrink-0">
        <div className="p-8">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-zinc-100 rounded flex items-center justify-center">
              <div className="w-5 h-5 border-2 border-black rotate-45"></div>
            </div>
            <div>
              <h1 className="text-zinc-100 font-bold tracking-tighter text-xl uppercase">FrotaGo</h1>
              <p className="text-[10px] text-zinc-500 font-mono tracking-widest">ID: 88-X / ORCHESTRATOR</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-2 mt-4">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => cn(
                "flex items-center gap-3 px-4 py-3 rounded text-[11px] font-bold uppercase tracking-widest transition-all",
                isActive 
                  ? "bg-zinc-100 text-black shadow-[0_0_15px_rgba(255,255,255,0.1)]" 
                  : "text-zinc-500 hover:text-zinc-100 hover:bg-zinc-900"
              )}
            >
              <item.icon className="w-4 h-4 flex-shrink-0" />
              {item.name}
            </NavLink>
          ))}
        </nav>

        <div className="p-6 border-t border-zinc-800">
          <button className="w-full flex items-center gap-3 px-4 py-3 text-[11px] font-bold uppercase tracking-widest text-zinc-500 hover:text-zinc-100 hover:bg-zinc-900 rounded transition-all">
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="h-20 bg-[#0A0A0A] border-b border-zinc-800 flex items-center justify-between px-10 flex-shrink-0">
          <div className="relative w-96 group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600 group-focus-within:text-zinc-100 transition-colors" />
            <input 
              type="text" 
              placeholder="SEARCH ASSET ENGINE..." 
              className="w-full pl-12 pr-4 py-2.5 bg-zinc-900/50 border border-zinc-800 rounded text-[11px] font-mono tracking-widest text-zinc-100 focus:outline-none focus:border-zinc-100/50 transition-all placeholder:text-zinc-700"
            />
          </div>

          <div className="flex items-center gap-12 font-mono text-[11px] tracking-widest">
            <div className="flex flex-col items-end">
              <span className="text-zinc-600 uppercase">Latency</span>
              <span className="text-zinc-100">14ms</span>
            </div>
            <div className="flex flex-col items-end">
              <span className="text-zinc-600 uppercase">Uptime</span>
              <span className="text-emerald-500">99.98%</span>
            </div>
            <div className="flex items-center gap-4 border-l border-zinc-800 pl-8">
              <button className="p-2 text-zinc-500 hover:text-zinc-100 transition-colors relative">
                <Bell className="w-5 h-5" />
                <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-emerald-500 rounded-full shadow-[0_0_8px_rgba(16,185,129,0.4)]"></span>
              </button>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded bg-zinc-100 flex items-center justify-center text-black font-bold text-xs">
                  AD
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 overflow-y-auto p-10 bg-[#0A0A0A]">
          <motion.div
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4 }}
          >
            <Outlet />
          </motion.div>
        </div>

        {/* Footer */}
        <footer className="h-14 px-10 border-t border-zinc-800 flex justify-between items-center text-[10px] uppercase tracking-[0.2em] text-zinc-600 font-bold flex-shrink-0 bg-[#0D0D0D]/50">
          <div className="flex gap-8">
            <span className="flex items-center gap-2"><div className="w-1 h-1 bg-emerald-500 rounded-full animate-pulse" /> Encrypted Session</span>
            <span>V.2.4.9_MASTER</span>
          </div>
          <div className="text-zinc-500">
            Node: <span className="text-zinc-100">AI-CENTER-USW</span> // Access: <span className="text-zinc-100">ADMIN</span>
          </div>
        </footer>
      </main>
    </div>
  );
}
